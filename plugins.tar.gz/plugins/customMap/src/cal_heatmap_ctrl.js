import TimeSeries from 'app/core/time_series2';
import {MetricsPanelCtrl} from 'app/plugins/sdk';
import moment from 'moment';
import kbn from 'app/core/utils/kbn';
import './bower_components/d3/d3.js';
import './bower_components/cal-heatmap/cal-heatmap.js';

import 'app/plugins/panel/graph/graph';
import 'app/plugins/panel/graph/legend';
import DataProcessor from 'app/plugins/panel/graph/data_processor';

export class CalHeatMapCtrl extends MetricsPanelCtrl {
  constructor($scope, $element, $injector) {
    super($scope, $injector);

    var panelDefaults = {
      aliasColors:[],
      yaxes: [
        {
          label: null,
          show: true,
          logBase: 1,
          min: null,
          max: null,
          format: 'short',
        },
        {
          label: null,
          show: true,
          logBase: 1,
          min: null,
          max: null,
          format: 'short',
        },
      ],
      xaxis: {
        show: true,
        mode: 'time',
        name: null,
        values: ['avg'],
        buckets: null,
      },
      legend: {
        show: true, // disable/enable legend
        values: false, // disable/enable legend values
        min: false,
        max: false,
        current: false,
        total: false,
        avg: false,
      },
      tooltip: {
        value_type: 'individual',
        shared: true,
        sort: 0,
      },
      fill:1,

    };
    $scope.ctrl=this;
    this.hiddenSeries=[];
    _.defaults(this.panel, angular.copy(panelDefaults));

    this.events.on('data-received', this.onDataReceived.bind(this));
    this.events.on('data-error', this.onDataError.bind(this));
    this.events.on('data-snapshot-load', this.onDataSnapshotLoad.bind(this));
    this.getCN();
  }
  historyData(callback,month,year)
  {
    //
    var range =this.timeSrv.timeRange();
    //this.range=this.timeSrv.timeRange();
    this.datasourceSrv
      .get(this.panel.datasource)
      .then(function (datasource) {
        this.datasource = datasource || this.datasource;
        //console.log(val)
        range.from=range.from.month(month).year(year)
          //range.from.subtract(val,"months");
          //range.from.year(2017);
        range.to=range.to.month(month).year(year)
          //range.to.subtract(val,"months");
          //range.to.year(2017);
        range.raw.from=range.from;
        range.raw.to=range.to;
        //this.applyPanelTimeOverrides();

        if (this.panel.maxDataPoints) {
          this.resolution = this.panel.maxDataPoints;
        } else {


          this.resolution = !this.panel.gridPos? Math.ceil($(window).width() * (this.panel.span / 12)):
          Math.ceil($(window).width() * (this.panel.gridPos.w / 24));
        }

        this.calculateInterval();

        return this.datasource;
      }.bind(this))
      .then(function (datasource) {

        this.datasource = datasource;

        if (!this.panel.targets || this.panel.targets.length === 0) {
          return this.$q.when([]);
        }

        // make shallow copy of scoped vars,
        // and add built in variables interval and interval_ms
        var scopedVars = Object.assign({}, this.panel.scopedVars, {
          __interval: { text: this.interval, value: this.interval },
          __interval_ms: { text: this.intervalMs, value: this.intervalMs },
        });

        var metricsQuery = {
          timezone: this.dashboard.getTimezone(),
          panelId: this.panel.id,
          range: range,
          rangeRaw: range.raw,
          interval: this.interval,
          intervalMs: this.intervalMs,
          targets: this.panel.targets,
          maxDataPoints: this.resolution,
          scopedVars: scopedVars,
          cacheTimeout: this.panel.cacheTimeout,
        };

        console.log(metricsQuery)
        return datasource.query(metricsQuery);
      }.bind(this))
      .then(callback.bind(this));
  }
  getCN(){
    window.$.getJSON('http://61.164.218.158:8080/AirServer/site/findAllSites').then((res) => {
      //console.info(res);
      this.locations = res;
      //this.render();
    });
  }
  onDataReceived(dataList) {
    this.dataList=[]
    this.seriesList=[]
    //this.dataList =  this.dataList .concat(dataList);
    var m=moment();
    var year=this.templateSrv.index.year.current.value||m.years()
    //console.info(this.templateSrv.index.year)
    for(var i=0;i<this.templateSrv.index.month.current.value.length;i++){
      let month=this.templateSrv.index.month.current.value[i]-1
      //console.info(val);
      this.historyData(function (result) {
        if(!result.data[0])return;
        const location = _.find(this.locations, (loc) => { return loc.key.toUpperCase() ===  result.data[0].target.toUpperCase(); });
        if(location)
        {
          result.data[0].target=location.name+' '+year+'年'+' '+(month+1)+'月';
        }
        result.data[0].datapoints.map(function (item) {
          var ti=item[1];
          //console.info(moment(ti).add(2,"days").format("YYYY-MM-DD HH:mm:SS"))

          item[1]=moment(ti).month(m.month()).year(m.year()).valueOf();
          //console.info(item[1])
          console.info(moment(ti).format("YYYY-MM-DD HH:mm:SS"));
          return item;
          //
        })

        this.dataList=this.dataList.concat(result.data);

        this.seriesList = processor.getSeriesList({
          dataList: this.dataList,
          range: this.range,
        });

        //console.info(this.seriesList);
        this.render(this.seriesList)
        this.events.emit('legend-rendering-complete');
      },month,year);
    }

    var processor = new DataProcessor(this.panel);
    this.render(this.seriesList)
    this.events.emit('legend-rendering-complete');
  }

  applyCN()
  {
    this.dataList.forEach(function (serie) {

    })

  }


  onDataSnapshotLoad(snapshotData) {
    this.onDataReceived(snapshotData.data);
  }

  onDataError(err) {
  }
}

CalHeatMapCtrl.templateUrl = 'module.html';
