import {BreadcrumbCtrl} from './breadcrumb_ctrl';

export {
  BreadcrumbCtrl as PanelCtrl
};
