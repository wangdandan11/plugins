import { BubbleChartCtrl } from './bubble_ctrl';

export {
    BubbleChartCtrl as PanelCtrl
};