import './libs/Chart.bundle';
import TimeSeries from 'app/core/time_series2';
import kbn from 'app/core/utils/kbn';
import {MetricsPanelCtrl} from 'app/plugins/sdk';
import _ from 'lodash';
import moment from 'moment';
import './css/barchart.css!';

const panelDefaults = {
	thresholds: '0,10',
	font:16,
	colors: ['rgba(50, 172, 45, 1)', 'rgba(241, 255, 0, 1)', 'rgba(245, 54, 54, 1)'],
	thresholds:'',
};

class BarChartCtrl extends MetricsPanelCtrl
{
	constructor($scope, $injector, $sce,contextSrv,$http)
	{
		super($scope, $injector);
		_.defaults(this.panel, panelDefaults);
		this.theme=  contextSrv.user.lightTheme ;
		this.http=$http;
		this.panel.chartId = 'chart_' + this.panel.id;
		this.containerDivId = 'container_'+this.panel.chartId;
		this.$sce = $sce;
		this.events.on('init-edit-mode', this.onInitEditMode.bind(this));
		this.events.on('data-received', this.onDataReceived.bind(this));
		this.events.on('data-snapshot-load', this.onDataReceived.bind(this));

		this.getChinese();
	}

	handleError(err){
		this.getPanelContainer().html('<p>Error:</p><pre>' + err + '</pre>');
	}
	
	onInitEditMode() {

		this.addEditorTab('显示', 'public/plugins/savantly-chart-panel/displayEditor.html', 2);
	}
	
	getPanelContainer(){
		return $(document.getElementById(this.containerDivId));
	}

	getChinese()
	{
		let p=this;
		this.http.get('http://61.164.218.158:8080/AirServer/site/findAllSites').then(function(resp)
		{
			p.cnData=resp.data;
			console.info(resp.data)
		},function(resp)
		{
			console.info(resp);
		});
	}
	
	onDataReceived(dataList)
	{
		if(dataList==null||dataList==undefined)
		{
			this.refresh();
			return;
		}

        let parent=this;
		if(this.cnData==null||this.cnData==undefined||this.cnData.length<=0)
		{
			this.http.get('http://61.164.218.158:8080/AirServer/site/findAllSites').then(function(resp)
			{
				parent.cnData=resp.data;
				let newArray=[];
				for(var i=0;i<dataList.length;i++)
				{
					for(var j=0;j<resp.data.length;j++)
					{
						if(dataList[i].target==resp.data[j].key)
						{
							dataList[i].target=resp.data[j].name;
							var item=Object.assign({},dataList[i]);
							newArray.push(item);
							break;
						}
					}
				}

				if (undefined != newArray) {
					parent.series = newArray.map(parent.seriesHandler.bind(parent));
				}

				parent.render(parent.series);
			},function(resp)
			{
				console.info(resp);
			});

		}else
		{
			let newArray1=[];
			for(var i=0;i<dataList.length;i++)
			{
				for(var j=0;j<this.cnData.length;j++)
				{
					if(dataList[i].target==this.cnData[j].key)
					{
						dataList[i].target=this.cnData[j].name;
						var item=Object.assign({},dataList[i]);
						newArray1.push(item);
						break;
					}
				}
			}

			if (undefined != newArray1) {
				parent.series = newArray1.map(parent.seriesHandler.bind(parent));
			}

			parent.render(parent.series);
		}
	}
	seriesHandler(seriesData) {
		var series = new TimeSeries({
			datapoints: seriesData.datapoints,
			alias: seriesData.target.replace(/"|,|;|=|:|{|}/g, '_')
		});
		series.flotpairs = series.getFlotPairs(this.panel.nullPointMode);
		//series=formatData(series,this.panel.decimal);
		return series;
	}

	changeColor(colorIndex, color){
		this.panel.colors[colorIndex] = color;
	}
	removeColor(colorIndex){
		this.panel.colors.splice(colorIndex,1);
	}

	addColor(){
		this.panel.colors.push('rgba(255, 255, 255, 1)');
	}
	invertColorOrder() {
		this.panel.colors.reverse();
		this.refresh();
	}
	updateThresholds(){
		this.refresh();
	}

	// #############################################
	// link 
	// #############################################

	link(scope, elem, attrs, ctrl) {
		var chartElement = elem.find('.chart');
    	var canvas = elem.find('.canvas')[0];
	    ctrl.canvas = canvas;
	    var gradientValueMax = elem.find('.gradient-value-max')[0];
	    var gradientValueMin = elem.find('.gradient-value-min')[0];

		this.events.on('render', function onRender(data)
		{
			render(data);
			ctrl.renderingCompleted();
		});

		function render(data){
			if(data==null||data==undefined)return;
			updateSize();
			updateCanvasStyle();
			initChart(data);
		}
		function updateSize(){
			elem.css('height', ctrl.height + 'px');
			chartElement.css('height',ctrl.height + 'px');
		}
		function updateCanvasStyle(){
			canvas.width = Math.max(chartElement[0].clientWidth, 100);
			var canvasContext = canvas.getContext("2d");
			canvasContext.clearRect(0, 0, canvas.width, canvas.height);

			var grd = canvasContext.createLinearGradient(0, 0, canvas.width, 0);
			var colorWidth = 1 / Math.max(ctrl.panel.colors.length, 1);
			for(var i=0; i<ctrl.panel.colors.length; i++){
				var currentColor = ctrl.panel.colors[i];
				grd.addColorStop(Math.min(colorWidth*i,1), currentColor);
			}
			canvasContext.fillStyle = grd;
			canvasContext.fillRect(0, 0, canvas.width, 3);

			gradientValueMax.innerText = Math.max.apply(Math, ctrl.panel.thresholds.split(','));
			gradientValueMin.innerText = Math.min.apply(Math, ctrl.panel.thresholds.split(','));
		}
        function initChart(data)
        {
        	data.sort(function (a,b) {
				return b.stats.current-a.stats.current;
            });

        	var names=new Array();
        	var vals=[];
        	var maxVals=[];
        	var minVals=[];
        	var avgVals=[];
        	var colors=[];
        	let maxlen=data.length>1000?1000:data.length;
        	for(var i=0;i<maxlen;i++)
			{
                names.push(data[i].alias);
                vals.push(data[i].stats.current);//console.info(data[i].stats);
                maxVals.push(data[i].stats.max);//console.info(data[i].stats.max);
                minVals.push(data[i].stats.min);//console.info(data[i].stats.min);
                avgVals.push(data[i].stats.avg);//console.info(data[i].stats.avg);
                var color=getVisColor(data[i].stats.current);
                colors.push(color);
			}
            var chartContainer = document.getElementById(ctrl.containerDivId);
        	if(chartContainer!=null)
            chartContainer.remove();
        	let dimen=maxlen*41>22000?22000:maxlen*41;

            chartElement.append('<canvas id="'+ctrl.containerDivId+'"+ height="'+dimen+'%"  style="overflow;min-height:100px;background-color:transparent;z-index:999"></canvas>');

            var chartContainer = document.getElementById(ctrl.containerDivId);
            Chart.defaults.global.defaultFontColor=ctrl.theme?'#333333':'#FFFFFF';
            Chart.defaults.global.defaultFontSize=ctrl.panel.font;
            Chart.defaults.global.maintainAspectRatio=true;

            var myChart = new Chart(chartContainer, {
                type: 'horizontalBar',
                data: {
                    labels: names,
                    datasets: [{
                        label: '当前值',
                        data: vals,//[12, 19, 3, 5, 2, 3],
                        backgroundColor: colors,
                        /*borderColor: */
                        borderWidth: 1
                    }]
                },
                options: {
                    layout: {
                        padding: {
                            left: -0,
                            right: 0,
                            top: 0,
                            bottom: 0
                        }
                    },
                    scales: {
                        yAxes: [{
                            //weight:100,
                            beforeUpdate: function(axes) {
                               /* console.log(axes);
                                //axes.maxWidth = 165;
                                axes.height=200;
                                console.log(axes.height);*/

                            },
                            display: true,
                            categoryPercentage: 1,
                            barPercentage: 1,
                            maxBarThickness:20,
                            //barThickness:25,
                            gridLines: {
                                display: false,
                                drawBorder: false,
                                drawOnChartArea: false,
                                offsetGridLines:true

							},
                            ticks: {
                                //autoSkip:true,
								min:'',
								max:'',
                                stepSize:350,
                                labelOffset:100,
                                autoSkip:false
                            },
                            scaleLabel: {
                                // actual label
                                labelString: 'bgbjkk',
                                fontColor:'#0067ac',
                                // display property
                                display: false,

                            },
                        }],
                        xAxes: [{
                            ticks: {
                                beginAtZero:true,

                            }
                        }],

                    },
                    legend: {
                        display: false,
                        labels: {
                            fontColor: 'rgb(255, 99, 132)'
                        },
                        position:'bottom'
                    },

					tooltips: {
                    	//xAlign:"center",
						//yAlign:"right",
						//bodyFontSize:17,
						//footerFontSize:16,
                        caretPadding: 0,
                        caretSize:3,
						backgroundColor: 'rgba(41,36,33,1)',
                        position:'average',
						callbacks: {
                            label: function(tooltipItem, data) {

                                var label = data.datasets[tooltipItem.datasetIndex].label || '';

                                if (label) {
                                    label += ': ';
                                }
                                if(tooltipItem.xLabel%1===0)label+=tooltipItem.xLabel;
                                else label += parseFloat(tooltipItem.xLabel).toFixed(2);
                                return label;
                            },
							title:function (arr,data) {
								return "";
                            },

                            beforeFooter:function(tooltipItems, data) {

								// label += tooltipItem.yLabel;
								var label='最大值:';
                                let val = maxVals[tooltipItems[0].index];
                                if(val%1===0) label+=val;
								else label+=parseFloat(val).toFixed(2);
								return label;
							},
                            footer:function(tooltipItems, data) {
                                var label='最小值:';
                                let val = minVals[tooltipItems[0].index];
                                if(val%1===0) label+=val;
                                else
                                    label+=parseFloat(val).toFixed(2);
                                return label;
                            },
                            afterFooter:function(tooltipItems, data) {
                                var label='平均值:';
                                let val = avgVals[tooltipItems[0].index];
                                if(val%1===0) label+=val;
                                else
                                    label+=parseFloat(val).toFixed(2);
                                return label;
                            },
						},
                        enabled: true,
                        mode: 'index',
                        position: 'nearest',
                        //custom: customTooltips
					}
				}
            });
        }
		function getVisColor(value)
		{
			var rgbColor = ctrl.getGradientForValue({thresholds: ctrl.panel.thresholds.split(',')}, value);
			return rgbColor;
		}
	}
	getGradientForValue(data, value){
		var min = Math.min.apply(Math, data.thresholds);
		var max = Math.max.apply(Math, data.thresholds);
		var absoluteDistance = max - min;
		var valueDistanceFromMin = value - min;
		var xPercent = valueDistanceFromMin/absoluteDistance;
		// Get the smaller number to clamp at 0.99 max
		xPercent = Math.min(0.99, xPercent);
		// Get the larger number to clamp at 0.01 min
		xPercent = Math.max(0.01, xPercent);

		return getColorByXPercentage(this.canvas, xPercent);
	}
}
function getColorByXPercentage(canvas, xPercent){
	var x = canvas.width * xPercent || 0;
	var context = canvas.getContext("2d");
	var p = context.getImageData(x, 1, 1, 1).data;
	var color = 'rgba('+[p[0] +','+ p[1] +','+ p[2] +','+ p[3]]+')';
	return color;
}

BarChartCtrl.templateUrl = 'module.html';

export {
	BarChartCtrl,
	BarChartCtrl as MetricsPanelCtrl
};
