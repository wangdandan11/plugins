
import {BarChartCtrl} from './BarChartControl';

export {
    BarChartCtrl as PanelCtrl
}; 