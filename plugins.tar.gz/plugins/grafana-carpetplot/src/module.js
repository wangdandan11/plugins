import { CarpetPlotCtrl } from './carpetplot-ctrl';

export {
  CarpetPlotCtrl as PanelCtrl
};
