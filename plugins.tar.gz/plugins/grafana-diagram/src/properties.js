
var pluginName = 'jdbranham-diagram-panel',
	diagramEditor = 'public/plugins/'+ pluginName +'/diagramEditor.html',
	displayEditor = 'public/plugins/'+ pluginName +'/displayEditor.html',
	compositeEditor = 'public/plugins/'+ pluginName +'/compositeEditor.html';

export {
	pluginName,
	diagramEditor,
	displayEditor,
	compositeEditor
}
