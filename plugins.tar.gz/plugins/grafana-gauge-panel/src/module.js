import {D3GaugePanelCtrl} from  './ctrl';

export {
  D3GaugePanelCtrl as PanelCtrl
};
