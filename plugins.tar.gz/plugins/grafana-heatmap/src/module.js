import {pluginName} from './properties';
import {HeatmapCtrl} from './heatmapControl';
/*import {loadPluginCss} from 'app/plugins/sdk';

loadPluginCss({
  dark: 'plugins/'+pluginName+'/libs/mermaid/dist/mermaid.css',
  light: 'plugins/'+pluginName+'/libs/mermaid/dist/mermaid.css'
});*/

export {
	HeatmapCtrl as PanelCtrl
}; 