
var pluginName = 'savantly-heatmap-panel',
	heatmapEditor = 'public/plugins/'+ pluginName +'/heatmapEditor.html',
	displayEditor = 'public/plugins/'+ pluginName +'/displayEditor.html';

export {
	pluginName,
	heatmapEditor,
	displayEditor
}