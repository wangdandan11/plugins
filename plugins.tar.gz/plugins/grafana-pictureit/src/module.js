import {PictureItCtrl} from './pictureit_ctrl';

export {
  PictureItCtrl as PanelCtrl
};
