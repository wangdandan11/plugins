import _ from 'lodash';
import {MetricsPanelCtrl} from 'app/plugins/sdk';
import './sprintf.js';
import './angular-sprintf.js';
import kbn from 'app/core/utils/kbn';
import {alertTab} from 'app/plugins/sdk';

const panelDefaults = {
	valueMaps: [],
	seriesList: [],
	series: [],
	bgimage: '',
	sensors: [],
	height: '400px',
	width: '100px'
};
const color={11:'red',2:'blue'};
const status={11:'<p><span>状态：</span>报警</p>',2:'<p><span>状态：</span>监测</p>'};
export class PictureItCtrl extends MetricsPanelCtrl  {
  
  
  constructor($scope, $injector,$http) {
    super($scope, $injector);
    _.defaults(this.panel, panelDefaults);
      this.http=$http;
    this.unitFormats = kbn.getUnitFormats();

    this.events.on('init-edit-mode', this.onInitEditMode.bind(this));
    this.events.on('panel-initialized', this.render.bind(this));
    this.events.on('data-received', this.onDataReceived.bind(this));
    this.events.on('data-snapshot-load', this.onDataReceived.bind(this));

      /*this.http.get('http://61.164.218.158:8080/AirServer/site/findAllSites').then(function(resp)
      {
          p.cnData=resp.data;
          console.info(resp.data)
      },function(resp)
      {
          console.info(resp);
      });*/
  }

  onDataReceived(dataList) {

      if(dataList==undefined||dataList==null)return;
      //console.info(dataList[0].rows);
      this.panel.valueMaps=dataList[0].rows;

      this.render();
  }
  
  deleteSensor(index) {
	this.panel.sensors.splice(index,1);
  }
  
  addSensor() {
	if (this.panel.sensors.length==0)
		this.panel.sensors.push({name: 'A-series', xlocation: 200,ylocation: 200,format: 'none', decimals: 'auto',bgcolor:'rgba(0, 0, 0, 0.58)',color:'#FFFFFF',size:22, bordercolor:'rgb(251, 4, 4)',visible:true});
	else {
		var lastSensor=this.panel.sensors[this.panel.sensors.length-1];
	
		this.panel.sensors.push({name: lastSensor.name, xlocation: 200,ylocation: 200,format: lastSensor.format, decimals: lastSensor.decimals,bgcolor:lastSensor.bgcolor,color:lastSensor.color,size:lastSensor.size, bordercolor:lastSensor.bordercolor,visible:true});
	}
  }
  
  setUnitFormat(subItem, index) {
  	this.panel.sensors[index].format = subItem.value;
  }

  onInitEditMode() {
    this.addEditorTab('Options', 'public/plugins/bessler-pictureit-panel/editor.html', 2);
      //this.addEditorTab('Alert', alertTab, 2);
  }
	
  link(scope, elem, attrs, ctrl) {
    var sensors;
    var valueMaps;

    const $panelContainer = elem.find('.panel-container');

    function pixelStrToNum(str) {
        return parseInt(str.substr(0,str.length-2));
    }
	
    function render() {
        if (!ctrl.panel.sensors) { return; }
	
        var width = pixelStrToNum($panelContainer.css("width"));
        var height = pixelStrToNum($panelContainer.css("height"));
	  
        sensors = ctrl.panel.sensors;	  
	    valueMaps = ctrl.panel.valueMaps;
        var sensorsLength = sensors.length;
        var valueMapsLength = valueMaps.length;
	  
        for (var sensor=0;sensor<sensorsLength;sensor++)//遍历每一个sensor
        {
                sensors[sensor].visible = sensors[sensor].xlocation<width && sensors[sensor].ylocation<height;
                sensors[sensor].ylocationStr=sensors[sensor].ylocation.toString()+"%";
                sensors[sensor].xlocationStr=sensors[sensor].xlocation.toString()+"%";
                sensors[sensor].sizeStr=sensors[sensor].size.toString()+"px";

                for (var valueMap=0;valueMap<valueMapsLength;valueMap++) {
                    if (sensors[sensor].name==valueMaps[valueMap][1]) {
                        //sensors[sensor].valueFormatted = kbn.valueFormats[sensors[sensor].format](valueMaps[valueMap].value,sensors[sensor].decimals, null);
                        sensors[sensor].bgcolor=color[valueMaps[valueMap][2]==11?11:2];
                        sensors[sensor].link_hoverall='';
                        sensors[sensor].link_hoverall=sensors[sensor].link_hover+status[valueMaps[valueMap][2]==11?11:2];
                        sensors[sensor].visible=!valueMaps[valueMap][3];
                        console.info(valueMaps[valueMap][3])
                        break;
                    }
                }
        }
    }

    this.events.on('render', function() {
      render();
      ctrl.renderingCompleted();
    });
  }
}

PictureItCtrl.templateUrl = 'module.html';
