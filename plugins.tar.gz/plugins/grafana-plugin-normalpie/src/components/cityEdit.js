import * as constant from "./common/constVal";
import moment from 'moment';
export class CityEditCtrl
{
  constructor($scope,$http,$rootScope)
  {
      $scope.cityModel=$rootScope.cityModel;
      $scope.title=$scope.cityModel==0?'新增城市':'编辑城市'
      $scope.cityModel=$scope.cityModel==0?{}:$scope.cityModel
        $scope.onChange=function () {
            $scope.productDate=!$scope.productDate
        }
        $scope.update=function update(){
            var format = 'YYYY-MM-DD HH:mm:ss';
            $scope.cityModel.createTime=moment($scope.cityModel.createTime).format(format)
          $http({
                method:'POST',
                url:constant.baseURL+'editCity',
                data:$scope.cityModel,
                dataType:'json',
                contentType:'application/json'

            }).then(function (re) {
              history.go(-1);
              alert('更新成功');
            },function (re) {
              console.info(re);
            })
        }
      $scope.kd=constant.kd
  }
}
CityEditCtrl.templateUrl = 'public/plugins/grafana-management/components/cityEdit.html';


