
export class CityViewCtrl
{
  constructor($scope,$rootScope,$location) {

      $scope.cityModel = $rootScope.cityModel;
      $scope.toEdit=function () {
          $location.path('plugins/grafana-management/page/cityedit').replace();
      }
  }
}
CityViewCtrl.templateUrl = 'public/plugins/grafana-management/components/cityView.html';


