const baseURL='http://61.164.218.158:8080/AirServer/grafana/';
    //'http://127.0.0.1:8080/grafana/';
//const baseURL='http://localhost:8080/grafana/';
const siteMonTypeMap={
    "1" : "空气质量",
    "2" : "空气污染重点企业",
    "3" : "饮用水水质",
    "4" : "污水水质",
    "5" : "水污染重点企业",
    "6" : "主要流域重点断面水质"
}
    const siteTypeMap = {
        "PUBLIC" : "公有站点",
        "PRIVATE" : "私有站点"
    }

//站点
    const statusMap = {
        "SITE_NORMAL" : "正常",
        "SITE_DISABLE" : "停用",
        "SITE_ERROR" : "异常"
    }
    const areaTypeMap ={
            "TWO" : "适用于居住、商业、工业混杂区"
        }

    const monTypeMap = {
    'AIR':'空气质量',
    'WATER':'水环境',
    'MULTI':'多功能'
};
//设备
const statusMapDevice = {
    'NORMAL':'正常',
    'STOP':'停用',
    'EXCEPTION':'异常'
}
function kd(e) {
    var k = e.keyCode;
    if( k == 229 || k ==0 ){
        alert('不能输入汉字！');
        this.value  = this.value.replace(/\D/g,'');
    }else if(!(( k >= 48 && k <= 57 ) || k == 8 || k == 190 )){
        return false;
    }
}
function isDate(d) {
    //console.info(d)
    if(d==null)return true;
    var reg =/[\d]{4}[\/-]{1}[\d]{1,2}[\/-]{1}[\d]{1,2}\s[\d]{1,2}[:][\d]{1,2}[:][\d]{1,2}/g;
    var r = d.match(reg);
    return !(r == null);
}
export {baseURL,
siteMonTypeMap,
siteTypeMap,
statusMap,
areaTypeMap,
    statusMapDevice,
    monTypeMap,
    isDate,
kd}