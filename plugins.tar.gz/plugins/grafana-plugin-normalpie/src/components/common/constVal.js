const baseURL='http://61.164.218.158:8080/AirServer/grafana/';
    //'http://127.0.0.1:8080/grafana/';
//const baseURL='http://localhost:8080/grafana/';
export {baseURL}