///<reference path="../../../headers/common.d.ts" />

import moment from 'moment';
import * as dateMath from 'app/core/utils/datemath';

export function inputDateDirective() {
  return {
    restrict: 'A',
    require: 'ngModel',
    link: function ($scope, $elem, attrs, ngModel) {
      var format = 'YYYY-MM-DD HH:mm:ss';
        //console.info(ngModel);

        //to model
      var fromUser = function (text) {
          //console.info(text);
        if (text.indexOf('now') !== -1) {
          if (!dateMath.isValid(text)) {
            ngModel.$setValidity("error", false);
            return undefined;
          }
          ngModel.$setValidity("error", true);
          return text;
        }

        var parsed;

        if ($scope.ctrl.isUtc) {
          parsed = moment(text, format);
        } else {
          parsed = moment(text,format);
        }

        if (!parsed.isValid()) {
          ngModel.$setValidity("error", false);
          return undefined;
        }

        ngModel.$setValidity("error", true);
        //console.info(ngModel);
          //console.info(parsed);
          //console.info(parsed);
        return parsed;

      };

      //to view
      var toUser = function (currentValue) {
        /*if (moment.isMoment(currentValue)) {
          return currentValue.format(format);
        } else {
          return currentValue;
        }*/
          //console.info(currentValue);
        if(currentValue==null||currentValue==undefined)return currentValue
        //console.info(moment(currentValue).format(format))
        return moment(currentValue).format(format);//currentValue.format(format);
      };

      ngModel.$parsers.push(fromUser);
      ngModel.$formatters.push(toUser);
    }
  };
}

