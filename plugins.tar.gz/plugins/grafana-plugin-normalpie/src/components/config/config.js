
export class ManagementAppConfigCtrl {
  constructor() { }
}
ManagementAppConfigCtrl.templateUrl = 'components/config.html';


