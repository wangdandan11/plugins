import moment from 'moment';
import * as constant from "./common/constVal";
export class DeviceEditCtrl
{
  constructor($scope,$http,$rootScope)
  {
      $scope.deviceTip = $rootScope.deviceModel;
      $scope.isnew=$scope.deviceTip==0?1:0;
      $scope.deviceTip=$scope.deviceTip==0?{}:$scope.deviceTip;

      $scope.http=$http;
      $scope.types=[{id:0,name:'全部站点'},{id:1,name:'公共站点'},{id:2,name:'私有站点'}];
      $scope.types2=[{id:1,name:'按站点名字'},{id:2,name:'按站点编号'},];
      $scope.siteMonTypeMap = constant.siteMonTypeMap
      $scope.siteTypeMap = constant.siteTypeMap
      $scope.URL=constant.baseURL+'searchSites';
      $scope.pageParams={siteType:0,type:1,tip:''};

      $scope.dismiss=function () {
          $scope.siteShow=!$scope.siteShow;

      };
      /*$scope.watch("deviceTip.siteEntity.siteName",function (x,y,z) {
          delete $scope.deviceTip.siteEntity;
      })*/
      $scope.choose=function (item) {
          //console.info(item);
          if($scope.deviceTip.siteEntity==undefined||$scope.deviceTip.siteEntity==null)$scope.deviceTip.siteEntity={}
          $scope.deviceTip.siteEntity.id=item.id;
          $scope.deviceTip.siteEntity.siteName=item.siteName;
          $scope.siteShow=!$scope.siteShow;
      };
      $scope.kd=constant.kd
      $scope.onChange=function (i) {
          if(i==1)
              $scope.productDate=!$scope.productDate
          else if(i==2)$scope.useDate1=!$scope.useDate1
          else $scope.lastCheckDate1=!$scope.lastCheckDate1
      }
      $scope.save=function () {
          var format = 'YYYY-MM-DD HH:mm:ss';
          /*$scope.deviceTip.createTime = document.getElementById("i1").value==''?null:document.getElementById("i1").value;
          $scope.deviceTip.useDate= document.getElementById("i3").value==''?null:document.getElementById("i3").value;
          $scope.deviceTip.lastCheckDate= document.getElementById("i5").value==''?null:document.getElementById("i5").value;*/
          $scope.deviceTip.createTime=$scope.deviceTip.createTime!=undefined?moment($scope.deviceTip.createTime).format(format):null;
          $scope.deviceTip.useDate=$scope.deviceTip.useDate!=undefined?moment($scope.deviceTip.useDate).format(format):null;
          $scope.deviceTip.lastCheckDate=$scope.deviceTip.lastCheckDate!=undefined?moment($scope.deviceTip.lastCheckDate).format(format):null;
          //console.info( $scope.deviceTip)
          if(!constant.isDate($scope.deviceTip.createTime)||!constant.isDate($scope.deviceTip.useDate)||!constant.isDate($scope.deviceTip.lastCheckDate))
          {
              appEvents.emit('alert-warning', ['时间格式错误!']);

              return;
          }

          //console.info($scope.deviceTip);
          $http({
              method: 'POST',
              url: constant.baseURL+'addDevice',
              //'http://127.0.0.1:8080/grafana/editDevice',
              data: $scope.deviceTip,
              contentType: 'application/json',
              dataType:'json',
          }).then(function (da)
          {
              history.go(-1);
              alert('更新成功');
          },function (re) {
              console.info(re.responseText);
          });
      }
  }
}

DeviceEditCtrl.templateUrl = 'public/plugins/grafana-management/components/deviceEdit.html';




