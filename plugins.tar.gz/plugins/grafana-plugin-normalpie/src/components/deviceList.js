import * as constant from "./common/constVal";
export class DeviceStreamPageCtrl
{
    constructor($scope,$http,$rootScope)
    {
        $scope.http=$http;
        this.selall=false;//全选标志
        this.checkedItems=[];
        $scope.URL=constant.baseURL+'searchDevices';
        $scope.pageParams=$rootScope.deviceTip?$rootScope.deviceTip:{
            tip:''
        };


        $scope.monTypeMap = constant.monTypeMap;
        $scope.statusMap = constant.statusMapDevice
        $scope.setModel=function (item) {
            $rootScope.deviceModel=item;
        }
        $scope.emptyModel=function () {
            $rootScope.deviceModel=0;
        }
        $scope.deleteDevice=function (item) {
            if(confirm('确定删除此项?'))
            {
                $.ajax({
                    type: 'POST',
                    url: constant.baseURL+'deleteDeviceByID',
                    //'http://127.0.0.1:8080/grafana/addCity',
                    data: {id:item.id},

                    dataType:'json',
                    success:function (da)
                    {
                        alert('删除成功');
                        $scope.$broadcast("fresh",'');
                    },
                    error:function (re) {
                        console.info(re);
                    }
                });
            }
        }
    }
    
    selectAll(all,names)
    {
        all? Object.assign(this.checkedItems, names):this.checkedItems.splice(0,this.checkedItems.length);
        //console.info(this.checkedItems);
    }
    updateSelection(event,x,ctrl)
    {
        var item=event.target;

        item.checked?ctrl.checkedItems.push(x):ctrl.checkedItems.splice(x,1);

    }
    deleteSelDevices()
    {
        if(confirm('确定删除选中项目?'))
        {
            var ids=[];
            for(let i=0;i<this.checkedItems.length;i++)
            {
                ids.push(this.checkedItems[i].id);
            }

            $.ajax({
                type: 'POST',
                traditional: true,
                url:constant.baseURL+'deleteSelDevices',
               // 'http://127.0.0.1:8080/grafana/deleteSelCities',
                data: {ids:ids},
                success:function (da)
                {
                    location.reload();
                    alert('删除成功');
                },
                error:function (re) {
                    console.info(re.responseText);
                }
            });
        }
    }
}
DeviceStreamPageCtrl.templateUrl = 'components/deviceList.html';


