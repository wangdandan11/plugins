import * as constant from "./common/constVal";
export class DeviceViewCtrl
{
  constructor($scope,$location,$rootScope)
  {
      $scope.deviceTip = $rootScope.deviceModel;
      $scope.monTypeMap = constant.monTypeMap
      $scope.toEdit=function()
      {
          $location.path('plugins/grafana-management/page/deviceedit').replace();
      };
      $scope.history=function () {
          window.open('dashboard/db/shi-shi-jian-ce')
      }
  }
}
DeviceViewCtrl.templateUrl = 'public/plugins/grafana-management/components/deviceView.html';




