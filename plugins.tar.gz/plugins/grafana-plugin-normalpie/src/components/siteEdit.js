import * as contant from "./common/constVal";
import moment from 'moment';
import {appEvents} from 'app/core/core';
const format = 'YYYY-MM-DD HH:mm:ss';
export class SiteEditCtrl
{
  constructor($scope,$http,$rootScope)
  {
       $scope.siteModel = $rootScope.siteModel;
       if( $scope.siteModel!=0)
       {
           $scope.cityName=$scope.siteModel.cityEntity==null||$scope.siteModel.cityEntity==undefined?'':$scope.siteModel.cityEntity.cityName;
           if($scope.siteModel.cityEntity==null||$scope.siteModel.cityEntity==undefined)
               $scope.siteModel.cityEntity={};
           $scope.isnew=0
       }else
       {
           $scope.siteModel={cityEntity:{},deviceEntities:[]}
           $scope.isnew=1;
       }


        $scope.siteMonTypeMap =contant.siteMonTypeMap;

        $scope.siteTypeMap = contant.siteTypeMap
        $scope.statusMap = contant.statusMap
        $scope.areaTypeMap = contant.areaTypeMap

      $scope.pageParams={tip:''};
      $scope.http=$http;
      $scope.URL=contant.baseURL+'searchCities';

      $scope.dismiss=function () {
          $scope.showCityList=!$scope.showCityList;
      };
      $scope.choose=function (item) {
          //console.info(item);
           $scope.siteModel.cityEntity.id=item.id;
          $scope.cityName=item.cityName;
          $scope.showCityList=!$scope.showCityList;
      };
       $scope.kd=contant.kd
      $scope.update=function (){
          let flag=0;
       $scope.siteModel.deviceEntities.forEach(function(item){
           //console.info(item);
           /*item.createTime=document.getElementById("i1").value==''?null:document.getElementById("i1").value;
           item.useDate=document.getElementById("i2").value==''?null:document.getElementById("i2").value;
           item.lastCheckDate=document.getElementById("i3").value==''?null:document.getElementById("i3").value;*/
           item.createTime=item.createTime!=undefined?moment(item.createTime).format(format):null;
           item.useDate=item.useDate!=undefined?moment(item.useDate).format(format):null;
           item.lastCheckDate=item.lastCheckDate!=undefined?moment(item.lastCheckDate).format(format):null;
            if(item.name==''||item.createTime==undefined||item.createTime==null||item.monType==undefined)
            {
                appEvents.emit('alert-warning', ['请填写完整设备信息!']);
                flag=1;
                return;
            }
           if(!contant.isDate(item.createTime)||!contant.isDate(item.useDate)||!contant.isDate(item.lastCheckDate))
           {
               appEvents.emit('alert-warning', ['设备时间格式错误!']);
               flag=1;
               return;
           }

            /*item.createTime=item.currentValue==''?null:moment(item.createTime).format('YYYY-MM-DD HH:mm:ss');
            item.lastCheckDate=item.lastCheckDate==''?null:moment(item.lastCheckDate).format('YYYY-MM-DD HH:mm:ss');
            item.useDate=item.useDate==''?null:moment(item.useDate).format('YYYY-MM-DD HH:mm:ss');*/
       })
          if(flag==1)return;


       $scope.siteModel.createTime=document.getElementById("s1").value;
          if(!contant.isDate($scope.siteModel.createTime))
          {
              appEvents.emit('alert-warning', ['站点创建时间格式错误!']);
              return;
          }
       // console.info($scope.siteModel)*/
          if($scope.siteModel.cityEntity.id==undefined)$scope.siteModel.cityEntity=null;

      $http({
              method: 'POST',
              url: contant.baseURL+'addSite',
              contentType: 'application/json',
              data:JSON.stringify($scope.siteModel)
          }).then(function successCallback(response) {
              if(response.data.code>=1)
              {
                  alert('添加成功')
                  history.back();
              }
              else alert('参数错误');
          }, function errorCallback(response) {
              alert('网络错误')
              console.info
             (response.data)
          });
      }


      $scope.add=function (){
          //console.info('aaaaa')
            let device={name:'',seqno:'',status:'NORMAL',firmware:'',monType:'',latitude:0,longitude:0};
            $scope.siteModel.deviceEntities.push(device);
      }
      $scope.onChange=function(val){
      if(val==1)
       $scope.createTime=!$scope.createTime;
       else if(val==2){
        $scope.useDate=!$scope.useDate;
       }

      else
      $scope.lastCheckDate=!$scope.lastCheckDate
      }
      $scope.createTime=0;
      $scope.useDate=0
      $scope.lastCheckDate=0

      $scope.remove=function (item) {
          $scope.siteModel.deviceEntities.splice(item,1)
      }
      $scope.onChange=function () {

              $scope.productDate = !$scope.productDate
      }
  }
}
SiteEditCtrl.templateUrl = 'public/plugins/grafana-management/components/siteEdit.html';


