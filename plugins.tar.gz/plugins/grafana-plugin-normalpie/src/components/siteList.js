import * as constant from "./common/constVal";

export class SiteStreamPageCtrl
{
    constructor($scope,$http,$rootScope)
    {
        $scope.http=$http;
        this.selall=false;//全选标志
        this.checkedItems=[];
        $scope.URL=constant.baseURL+'searchSites';
        $scope.pageParams={siteType:0,type:1,tip:''};
        $scope.types=[{id:0,name:'全部站点'},{id:1,name:'公共站点'},{id:2,name:'私有站点'}];
        $scope.types2=[{id:1,name:'按站点名字'},{id:2,name:'按站点编号'},];
        $scope.siteMonTypeMap = constant.siteMonTypeMap
        $scope.siteTypeMap = constant.siteTypeMap
        $scope.statusMap = constant.statusMap

        $scope.deleteCity=function (item) {
            //console.info(item);
            if(confirm('确定删除此项?'))
            {
                $.ajax({
                    type: 'POST',
                    url: constant.baseURL+'deleteSiteByID',
                    data: {siteid:item.id},
                    contentType:'application/x-www-form-urlencoded',
                    success :function (re) {
                        alert('删除成功');
                        $scope.$broadcast("fresh",'');

                    },
                    error:function (re) {
                       // console.info('iiijjj');

                    }
                });
            }
        }

        $scope.setModel=function (item) {
            $rootScope.siteModel=item;
        }
        $scope.emptyModel=function () {
            $rootScope.siteModel=0;
        }
    }
    selectAll(all,names)
    {
        all? Object.assign(this.checkedItems, names):this.checkedItems.splice(0,this.checkedItems.length);
        //console.info(this.checkedItems);
    }
    updateSelection(event,x,ctrl)
    {
        var item=event.target;

        item.checked?ctrl.checkedItems.push(x):ctrl.checkedItems.splice(x,1);

    }
    deleteSelCities()
    {
        if(confirm('确定删除选中项目?'))
        {
            var ids=[];
            for(let i=0;i<this.checkedItems.length;i++)
            {
                ids.push(this.checkedItems[i].id);
            }

            $.ajax({
                type: 'POST',
                traditional: true,
                url: constant.baseURL+'deleteSelSites',
               // 'http://127.0.0.1:8080/grafana/deleteSelCities',
                data: {ids:ids},
                success:function (da)
                {
                    location.reload();
                    alert('删除成功');
                },
                error:function (re) {
                    console.info(re.responseText);
                }
            });
        }
    }
}
SiteStreamPageCtrl.templateUrl = 'components/siteList.html';


