import * as contant from "./common/constVal"
export class SiteViewCtrl
{
  constructor($scope,$http,$rootScope,$location)
  {
      $scope.siteModel = $rootScope.siteModel;
      $scope.siteMonTypeMap =contant.siteMonTypeMap;

        $scope.siteTypeMap = contant.siteTypeMap
        $scope.statusMap = contant.statusMap
        $scope.areaTypeMap = contant.areaTypeMap
        $scope.autoUpdMap = {
            true : "是",
            false : "否"
        };
      $scope.toEdit=function () {
          $location.path('plugins/grafana-management/page/siteedit').replace();
      }
      $scope.history=function () {
          window.open('dashboard/db/shi-shi-jian-ce')
      }
  }
}
SiteViewCtrl.templateUrl = 'public/plugins/grafana-management/components/siteView.html';


