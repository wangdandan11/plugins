export default class ExampleAppDatasource {

  constructor() {}

  query(options) {
    return [];
  }

  testDatasource() {
    return false;
  }
}
