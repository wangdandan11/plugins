import {DeviceStreamPageCtrl} from './components/deviceList';
import {DeviceEditCtrl} from './components/deviceEdit';
import {DeviceViewCtrl} from './components/deviceView';
import {SiteEditCtrl} from './components/siteEdit';
import {SiteViewCtrl} from './components/siteView';
import {SiteStreamPageCtrl} from './components/siteList';
import {ManagementAppConfigCtrl} from './components/config/config';
import {CityListCtrl} from './components/cityList';
import {CityViewCtrl} from './components/cityView';
import {CityEditCtrl} from './components/cityEdit';

import './components/common/custom.css!';
import angular from 'angular';
import {pageDirective} from './components/common/pager';
import {inputDateDirective} from './components/common/input_date';
angular.module("grafana.directives").directive('inputDatetime', inputDateDirective);
angular.module('grafana.directives').directive('pager', pageDirective);

export {
    DeviceStreamPageCtrl,
    DeviceEditCtrl,
    SiteEditCtrl,
    SiteViewCtrl,
    SiteStreamPageCtrl,
    DeviceViewCtrl,
    ManagementAppConfigCtrl as ConfigCtrl,
    CityListCtrl,
    CityViewCtrl,
    CityEditCtrl
};
