import './libs/Chart.bundle';
import TimeSeries from 'app/core/time_series2';
import {MetricsPanelCtrl} from 'app/plugins/sdk';
import _ from 'lodash';
import moment from 'moment';
import './css/piechart.css!';

const panelDefaults = {
	shapes:['pie','doughnut','polarArea'],
	shape:'pie',
	thresholds: '0,10',
	labels:''
};

class PieCtrl extends MetricsPanelCtrl {
	constructor($scope, $injector, $sce,contextSrv) {
		super($scope, $injector);
		_.defaults(this.panel, panelDefaults);

		this.lightTheme=contextSrv.user.lightTheme;
		this.panel.chartId = 'chart_' + this.panel.id;
		this.containerDivId = 'container_'+this.panel.chartId;
		this.$sce = $sce;
		this.events.on('init-edit-mode', this.onInitEditMode.bind(this));
		this.events.on('data-received', this.onDataReceived.bind(this));
		this.events.on('data-snapshot-load', this.onDataReceived.bind(this));
	}

	handleError(err){
		this.getPanelContainer().html('<p>Error:</p><pre>' + err + '</pre>');
	}
	getPanelContainer(){
		return $(document.getElementById(this.containerDivId));
	}
	onInitEditMode() {
		this.addEditorTab('显示', 'public/plugins/wzd-grafana-pie/displayEditor.html', 2);
	}
	onDataReceived(dataList)
	{
		if(undefined != dataList) {
			this.series = dataList.map(this.seriesHandler.bind(this));
		}

        this.render(this.series);
	}
	seriesHandler(seriesData) {
		var series = new TimeSeries({
			datapoints: seriesData.datapoints,
			alias: seriesData.target.replace(/"|,|;|=|:|{|}/g, '_')
		});
	    series.flotpairs = series.getFlotPairs(this.panel.nullPointMode);
	    return series;
	}
	changeColor(colorIndex, color){
		this.panel.colors[colorIndex] = color;
	}
	
	removeColor(colorIndex){
		this.panel.colors.splice(colorIndex,1);
	}
	
	addColor(){
		this.panel.colors.push('rgba(255, 255, 255, 1)');
	}
	// #############################################
	// link 
	// #############################################

	link(scope, elem, attrs, ctrl)
	{
		var chartElement = elem.find('.piechart');

		this.events.on('render', function onRender(data) {

			render(data);
			ctrl.renderingCompleted();
		});
		
    	function render(data){
			chartElement.css('height', ctrl.height + 'px');
            initChart(data);
    	}
        function initChart(data)
        {
			if(data==null||data==undefined)return;
        	var legfontColor=ctrl.lightTheme?'rgb(0, 0, 0)':'rgb(255, 255, 255)';
        	data.sort(function (a,b) {
				return a.stats.current-b.stats.current;
            });
        	var names=ctrl.panel.labels.split(',');
        	var thresholds=ctrl.panel.thresholds.split(',');
        	var colors=ctrl.panel.colors;
        	var vals=[];
        	for(var n=0;n<thresholds.length;n++)vals[n]=0;

        	for(var i=0;i<data.length;i++)
			{
				for(var index=0;index<thresholds.length;index++)
				{
					if(data[i].stats.current<parseInt(thresholds[index]))
					{
                        vals[index]++;
                        break;
					}
				}
			}
			var totalval=0;
            var j = vals.length;
            while (j--) {
                totalval += parseInt(vals[j]);
            }

            var chartContainer = document.getElementById(ctrl.containerDivId);
        	if(chartContainer!=null)
            chartContainer.remove();
            chartElement.append('<canvas id="'+ctrl.containerDivId+'"></canvas>');
            var chartContainer = document.getElementById(ctrl.containerDivId);
            var myChart = new Chart(chartContainer, {
                type: ctrl.panel.shape,
                data: {
                    labels: names,
                    datasets: [{
                        label: 'aqi指数',
                        data: vals,
                        backgroundColor:colors,
                        borderWidth: 1
                    }]
                },
                options: {
                    title: {
                        display: true,
                        //text: '污染状况分布'
                    },
                    layout: {
                        padding: {
                            left: 0,
                            right: 0,
                            top: 0,
                            bottom: 0
                        }
                    },
                    legend: {
                        display: true,
                        labels: {
                            boxWidth:15,
                            fontColor: legfontColor,
                            fontSize:12,
                        },
                        position:'bottom'
                    },
                    tooltips:{
                        callbacks: {

                            label: function(tooltipItem, data) {

                                var label = data.labels[tooltipItem.index] || '';

                                if (label) {
                                    label += ': ';
                                }
                                var yval=data.datasets[tooltipItem.datasetIndex].data[tooltipItem.index];

								var percent=parseFloat(yval*100/totalval).toFixed(1);
                                label+=percent+'%';
                                return label;
                            }
                        }

                    },

                }
            });
        }
	}
// End Class
}

PieCtrl.templateUrl = 'module.html';

export {
    PieCtrl,
    PieCtrl as MetricsPanelCtrl
};
