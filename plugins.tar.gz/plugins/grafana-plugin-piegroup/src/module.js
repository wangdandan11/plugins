
import {PieCtrl} from './PieCtrl';
export {
    PieCtrl as PanelCtrl
}; 