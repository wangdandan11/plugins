import _ from 'lodash';
import L from './libs/baiduleaflet';
import HeatmapOverlay from './libs/leaflet-heatmap'
import './css/MarkerCluster.css!';
import './css/MarkerCluster.Default.css!';
import './css/screen.css!';
import BMap from './libs/baiduMapAPI';
import LM from './libs/leaflet.markercluster-src';
import './css/jquery-ui.css!';
import './libs/jquery-ui';

const mapstyles=
  't%3Aroad%7Ce%3Aall%7Cv%3Aoff%2Ct%3Awater%7Ce%3Aall%7Cc%3A%23021019%2Ct%3Ahighway%7Ce%3Ag.f%7Cv%3Aoff%7Cc%3A%23000000%2Ct%3Ahighway%7Ce%3Ag.s%7Cv%3Aoff%7Cc%3A%23147a92%2Ct%3Aarterial%7Ce%3Ag.f%7Cc%3A%23000000%2Ct%3Aarterial%7Ce%3Ag.s%7Cc%3A%230b3d51%2Ct%3Alocal%7Ce%3Ag%7Cc%3A%23000000%2Ct%3Aland%7Ce%3Aall%7Cc%3A%2308304b%2Ct%3Arailway%7Ce%3Ag.f%7Cc%3A%23000000%2Ct%3Arailway%7Ce%3Ag.s%7Cc%3A%2308304b%2Ct%3Asubway%7Ce%3Ag%7Cl%3A-70%2Ct%3Abuilding%7Ce%3Ag.f%7Cc%3A%23000000%2Ct%3Aall%7Ce%3Al.t.f%7Cc%3A%23857f7f%2Ct%3Aall%7Ce%3Al.t.s%7Cc%3A%23000000%2Ct%3Abuilding%7Ce%3Ag%7Cc%3A%23022338%2Ct%3Agreen%7Ce%3Ag%7Cc%3A%23062032%2Ct%3Aboundary%7Ce%3Aall%7Cc%3A%231e1c1c%2Ct%3Amanmade%7Ce%3Aall%7Cc%3A%23022338';
const baseMaps = {
    Normal: new window.L.TileLayer.BaiduLayer("Normal.Map",{styles:mapstyles}),
    satellite: new window.L.TileLayer.BaiduLayer("Satellite.Map",{styles:mapstyles}),
    road: new window.L.TileLayer.BaiduLayer("Satellite.Road",{styles:mapstyles}),
    cnormal: new window.L.TileLayer.BaiduLayer("CustomStyle.Map.normal",{styles:mapstyles}),
    light: new window.L.TileLayer.BaiduLayer("CustomStyle.Map"
      , {styles: 't%3Aroad%7Ce%3Aall%7Cv%3Aoff'}),
    dark: new window.L.TileLayer.BaiduLayer("CustomStyle.Map.dark" ,{styles: 't%3Aroad|e%3Aall|v%3Aoff|c%3A%23010b14%2Ct%3Aland|e%3Aall|c%3A%23ffffff%2Ct%3Awater|e%3Aall|c%3A%230f0e0e%2Ct%3Amanmade|e%3Aall|v%3Aoff|c%3A%23a9c5df|l%3A-6%2Ct%3Aland|e%3Aall|c%3A%23201e1e'}),
    redalert: new window.L.TileLayer.BaiduLayer("CustomStyle.Map.redalert",{styles:mapstyles}),
    googlelite: new window.L.TileLayer.BaiduLayer("CustomStyle.Map.googlelite",{styles:mapstyles}),
    grassgreen: new window.L.TileLayer.BaiduLayer("CustomStyle.Map.grassgreen",{styles:mapstyles}),
    midnight: new window.L.TileLayer.BaiduLayer("CustomStyle.Map",
      {styles:mapstyles}),
    pink: new window.L.TileLayer.BaiduLayer("CustomStyle.Map.pink",{styles:mapstyles}),
    darkgreen: new window.L.TileLayer.BaiduLayer("CustomStyle.Map.darkgreen",{styles:mapstyles}),
    bluish: new window.L.TileLayer.BaiduLayer("CustomStyle.Map.bluish",{styles:mapstyles}),
    grayscale: new window.L.TileLayer.BaiduLayer("CustomStyle.Map.grayscale",{styles:mapstyles}),
    hardedge: new window.L.TileLayer.BaiduLayer("CustomStyle.Map.hardedge",{styles:mapstyles})

};
const strMaps = {
    'Normal': [baseMaps.Normal],
    'satellite': [baseMaps.satellite],
    'road': [baseMaps.road],
    'cnormal': [baseMaps.cnormal],
    'light': [baseMaps.light],
    'dark': [baseMaps.dark],
    'redalert': [baseMaps.redalert],
    'googlelite': [baseMaps.googlelite],
    'grassgreen': [baseMaps.grassgreen],
    'midnight': [baseMaps.midnight],
    'pink': [baseMaps.pink],
    'darkgreen': [baseMaps.darkgreen],
    'bluish': [baseMaps.bluish],
    'grayscale': [baseMaps.grayscale],
    'hardedge': [baseMaps.hardedge]
};

export default class WorldMap
{
    constructor(ctrl, mapContainer)
    {
          this.ctrl = ctrl;
          this.mapContainer = mapContainer;
          this.createMap();
          this.circles = [];
            this.heatmapLayer=null;
    }
    createMap()
    {
        const mapCenter = window.L.latLng(parseFloat(this.ctrl.panel.mapCenterLatitude), parseFloat(this.ctrl.panel.mapCenterLongitude));
        var options = {
          crs: window.L.CRS.EPSGB3857,
          center:mapCenter,
          zoom: 17,
          layers:strMaps[this.ctrl.panel.Layers]
        };

        this.map = window.L.map(this.mapContainer, options).fitWorld().setView([30,120.5],this.ctrl.panel.initialZoom);
        window.L.control.layers(baseMaps).addTo(this.map);
        this.map.panTo(mapCenter);

    }
    resize() {
        this.map.invalidateSize();
    }
    setZoom(zoomFactor) {
        this.map.setZoom(parseInt(zoomFactor, 10));
    }
    panToMapCenter() {
        this.map.panTo([parseFloat(this.ctrl.panel.mapCenterLatitude), parseFloat(this.ctrl.panel.mapCenterLongitude)]);
        this.ctrl.mapCenterMoved = false;

    }
    remove() {
        this.circles = [];
        if (this.circles) this.removeCircles();
        if (this.legend) this.removeLegend();
        this.removeHeatMap();
        this.map.remove();
    }
    /*Legend*/
    createLegend() {
      this.legend = window.L.control({position: 'bottomleft'});
      this.legend.onAdd = () => {
        this.legend._div = window.L.DomUtil.create('div', 'info legend');
        this.legend.update();
        return this.legend._div;
      };

      this.legend.update = () => {
        const thresholds = this.ctrl.data.thresholds;
        let legendHtml = '';
        legendHtml += '<i style="background:' + this.ctrl.panel.colors[0] + '"></i> ' +
            '&lt; ' + thresholds[0] + '<br>';
        for (let index = 0; index < thresholds.length; index += 1) {
          legendHtml +=
            '<i style="background:' + this.getColor(thresholds[index] + 1) + '"></i> ' +
            thresholds[index] + (thresholds[index + 1] ? '&ndash;' + thresholds[index + 1] + '<br>' : '+');
        }
        this.legend._div.innerHTML = legendHtml;
      };
      this.legend.addTo(this.map);
      // this.createHeatLayer();
    }
    removeLegend() {
        //this.legend.removeFrom(this.map);
        this.legend = null;
    }
    addFocus(lat,lon)
    {
        var myIcon = L.divIcon({
            className:'',

            html:'<div style="border: 3px #a72525 solid;width: 4rem;height: 4rem;border-radius: 50%;' +
            '"></div>'});

        L.marker([lat, lon], {icon: myIcon

        }).addTo(this.map);
    }
    /*Circles*/
    drawCircles() {
        //console.info('drawCircles');
        const data = this.filterEmptyAndZeroValues(this.ctrl.data);
        if (this.needToRedrawCircles(data)) {
            this.clearCircles();
            this.createCircles(data);

        } else {
            this.updateCircles(data);
        }
    }
    needToRedrawCircles(data) {
        //console.info('needToRedrawCircles');
        //console.info(data);
        if (!this.circles||this.circles.length<=0)return true;
      if (this.circles.length === 0 && data.length > 0) return true;

      if (this.circles.length !== data.length) return true;
      const locations = _.map(_.map(this.circles, 'options'), 'location').sort();
      const dataPoints = _.map(data, 'key').sort();
      return !_.isEqual(locations, dataPoints);
    }

    filterEmptyAndZeroValues(data) {
      return _.filter(data, (o) =>
          { return !(this.ctrl.panel.hideEmpty && _.isNil(o.value)) && !(this.ctrl.panel.hideZero && o.value === 0); });
    }

    clearCircles() {
      if (this.circles) {
        //this.circlesLayer.removeLayer(this.circles);
        this.removeCircles(this.circles);
        this.circles = [];
      }
    }
    createCircles(data) {
          const circles = [];
          if(!data||data.length<=0){/*this.ctrl.refresh();*/return;}
          //console.info(data);
          data.forEach((dataPoint) => {
            if (!dataPoint.locationName) return;
            circles.push(this.createCircle(dataPoint));
          });
          //maker无聚合layer
          //this.circlesLayer = this.addCircles(circles);
          //this.circles = circles;
          //marker聚合layer
          var markers = L.markerClusterGroup();
          for (var i = 0; i < circles.length; i++) {
            markers.addLayer(circles[i]);
          }
          this.circles = markers;
          this.map.addLayer(this.circles);
        //
    }

    updateCircles(data)
    {

      data.forEach((dataPoint) =>
      {
        if (!dataPoint.locationName) return;
        const circle = _.find(this.circles, (cir) => { return cir.options.location === dataPoint.key; });

        if (circle) {
          circle.setRadius(this.calcCircleSize(dataPoint.value || 0));
          circle.setStyle({
            color: this.getColor(dataPoint.value),
            fillColor: this.getColor(dataPoint.value),
            fillOpacity: 1,
            location: dataPoint.key,
          });
          circle.unbindPopup();
          this.createPopup(circle, dataPoint.locationName, dataPoint.valueRounded);
        }
      });
    };
    //自制水滴形marker
    createCircle(dataPoint) {
        //console.info(dataPoint);
        const circleValue = this.calcCircleSize(dataPoint.valueFormatted || 0)/9+1;
        const myicon = new window.L.divIcon({
        className:'',
        html: '<div style="background-color: ' + this.getColor(dataPoint.valueFormatted) + ';width: ' + circleValue + 'rem;height: '
            + circleValue + 'rem;display: block;border-radius: 3rem 3rem 0;transform: rotate(45deg);border: 1px solid #FFFFFF"/>'
        })

        var marker = window.L.marker([dataPoint.locationLatitude, dataPoint.locationLongitude],{
          icon : myicon
        });

        this.createPopup(marker, dataPoint.locationName, dataPoint.valueRounded);
        return marker;
    }

    calcCircleSize(dataPointValue) {
        const circleMinSize = parseInt(this.ctrl.panel.circleMinSize, 10) || 2;
        const circleMaxSize = parseInt(this.ctrl.panel.circleMaxSize, 10) || 30;

        if (this.ctrl.data.valueRange === 0) {
          return circleMaxSize;
        }

        const dataFactor = (dataPointValue - this.ctrl.data.lowestValue) / this.ctrl.data.valueRange;
        const circleSizeRange = circleMaxSize - circleMinSize;

        return (circleSizeRange * dataFactor) + circleMinSize;
    }

    createPopup(circle, locationName, value) {
        const unit = value && value === 1 ? this.ctrl.panel.unitSingular : this.ctrl.panel.unitPlural;
        const label = (locationName + ': ' + value + ' ' + (unit || '')).trim();
        circle.bindPopup('<font size="6">'+label+'</font>',
            {'offset': window.L.point(0, -2), 'className': 'worldmap-popup', 'closeButton': this.ctrl.panel.stickyLabels});

        circle.addEventListener("mouseover", function(evt){
          this.openPopup();
        })
        if (!this.ctrl.panel.stickyLabels) {
          circle.addEventListener("mouseout", function(evt){
          circle.closePopup();
        })
        }
    }

    getColor(value) {
      for (let index = this.ctrl.data.thresholds.length; index > 0; index -= 1) {
        if (value >= this.ctrl.data.thresholds[index - 1]) {
          return this.ctrl.panel.colors[index];
        }
      }
      return _.first(this.ctrl.panel.colors);
    }
    addCircles(circles) {
      return window.L.layerGroup(circles).addTo(this.map);
    }

    removeCircles() {
        if (this.circles) this.map.removeLayer(this.circles);
        this.circles=[];
    }

    /*heatMap*/
    createHeatLayer()
    {
        if(this.heatmapLayer){
            this.updateMap(this.heatmapLayer);
            return;
        }
        let step=(1/this.ctrl.panel.colors.length).toFixed(2);
        var steps=[];
        for(let x=1;x<=this.ctrl.panel.colors.length;x++)
        {
            let v=step*x;
            if(v>1)v=1;
            steps.push(v.toString().substr(v.toString().indexOf("."),3));
        }
        var gradin={};
        for(let y=0;y<this.ctrl.panel.colors.length;y++)
        {
            gradin[steps[y]]=this.ctrl.panel.colors[y];
        }
        //console.info(gradin);
        var cfg = {
            // radius should be small ONLY if scaleRadius is true (or small radius is intended)
            // if scaleRadius is false it will be the constant radius used in pixels
            "radius": 30,
            "maxOpacity": .8,
            // scales the radius based on map zoom
            "scaleRadius": false,
            blur: 0.85,
            // if set to false the heatmap uses the global maximum for colorization
            // if activated: uses the data maximum within the current map boundaries
            //   (there will always be a red spot with useLocalExtremas true)
            "useLocalExtrema": false,
            // which field name in your data represents the latitude - default "lat"
            latField: 'lat',
            // which field name in your data represents the longitude - default "lng"
            lngField: 'lng',
            // which field name in your data represents the data value - default "value"
            valueField: 'count',
            gradient: {
                .33:'rgba(24, 242, 37, 0.9)',
                .66:'rgba(247, 241, 20, 0.89)',
                .99:'rgb(246, 102, 39)'
            }
        };
        this.heatmapLayer = new HeatmapOverlay(cfg);

        this.map.addLayer(this.heatmapLayer);
        this.updateMap(this.heatmapLayer);
    }
    updateMap(heatmapLayer)
    {
        var vals=this.ctrl.panel.thresholds.split(",");
        var dataPoints=[];
        //console.info(this.ctrl.locations);
        for(var i=0;i<this.ctrl.data.length;i++)
        {
            if(this.ctrl.data[i].locationLatitude!=undefined&&this.ctrl.data[i].locationLongitude!=undefined)
            {
                let p={lat:this.ctrl.data[i].locationLatitude,lng:this.ctrl.data[i].locationLongitude
                    ,count:this.ctrl.data[i].valueFormatted};
                dataPoints.push(p);
            }
        }
        var testData={
            max:
            Number(vals[vals.length-1].trim()),
            min: Number(vals[0].trim()),
            data: dataPoints
        }
        this.heatmapLayer.setData(testData);
    }
    removeHeatMap() {
        if (this.heatmapLayer) this.map.removeLayer(this.heatmapLayer);
        this.heatmapLayer=null;
    }
}
