/* eslint import/no-extraneous-dependencies: 0 */
import {MetricsPanelCtrl} from 'app/plugins/sdk';
import TimeSeries from 'app/core/time_series2';
import kbn from 'app/core/utils/kbn';
import _ from 'lodash';
import mapRenderer from './map_renderer';
import DataFormatter from './data_formatter';
import './css/worldmap-panel.css!';

import moment from 'moment';
const format = 'YYYY-MM-DD HH:mm:ss';
const panelDefaults = {
  mapMode:1,
  maxDataPoints: 1,
  mapCenter: '(0°, 0°)',
  mapCenterLatitude: 0,
  mapCenterLongitude: 0,
  initialZoom: 1,
  valueName: 'total',
  Layers: 'light',
  circleMinSize: 2,
  circleMaxSize: 30,
  locationData: 'countries',
  thresholds: '0,10,20',
  colors: ['rgba(245, 54, 54, 0.9)', 'rgba(237, 129, 40, 0.89)', 'rgba(50, 172, 45, 0.97)'],
  unitSingle: '',
  unitPlural: '',
  showLegend: true,
  esMetric: 'Count',
  decimals: 0,
  hideEmpty: false,
  hideZero: false,
  stickyLabels: false
};

const mapCenters = {
  '(0°, 0°)': {mapCenterLatitude: 0, mapCenterLongitude: 0},
  'North America': {mapCenterLatitude: 40, mapCenterLongitude: -100},
  'Europe': {mapCenterLatitude: 46, mapCenterLongitude: 14},
  'West Asia': {mapCenterLatitude: 26, mapCenterLongitude: 53},
  'SE Asia': {mapCenterLatitude: 10, mapCenterLongitude: 106}
};

export default class WorldmapCtrl extends MetricsPanelCtrl
{
  constructor($q,$scope, $injector, contextSrv,templateSrv,backendSrv,$interval)
  {
      super($scope, $injector);
      this.q=$q;

      this.timeSrv = $injector.get('timeSrv');
      this.range = this.timeSrv.timeRange();

      $scope.frequency=600;//播放频率
      this.panel.playStatus='stop';
      $scope.playBackIndex=0;
        //ctrl.panel.mapMode=1;//默认地图

      this.scope=$scope;
      this.setMapProvider(contextSrv);
      _.defaults(this.panel, panelDefaults);

      this.dataFormatter = new DataFormatter(this, kbn);

      this.events.on('init-edit-mode', this.onInitEditMode.bind(this));
      this.events.on('data-received', this.onDataReceived.bind(this));
      this.events.on('panel-teardown', this.onPanelTeardown.bind(this));
      this.events.on('data-snapshot-load', this.onDataSnapshotLoad.bind(this));

      this.loadLocationDataFromFile();

      Date.prototype.Format = function (fmt) { //author: meizz
          var o = {
              "M+": this.getMonth() + 1, //月份
              "d+": this.getDate(), //日
              "h+": this.getHours(), //小时
              "m+": this.getMinutes(), //分
              "s+": this.getSeconds(), //秒
              "q+": Math.floor((this.getMonth() + 3) / 3), //季度
              "S": this.getMilliseconds() //毫秒
          };
          if (/(y+)/.test(fmt)) fmt = fmt.replace(RegExp.$1, (this.getFullYear() + "").substr(4 - RegExp.$1.length));
          for (var k in o)
              if (new RegExp("(" + k + ")").test(fmt)) fmt = fmt.replace(RegExp.$1, (RegExp.$1.length == 1) ? (o[k]) : (("00" + o[k]).substr(("" + o[k]).length)));
          return fmt;
      }
      this.timestep=new Date().Format('yyyy-MM-dd hh:mm:ss');
      this.render();
  }
    onInitEditMode() {
        this.addEditorTab('Worldmap',
            'public/plugins/grafana-worldmap-panel/partials/editor.html', 2);
    }

  setMapProvider(contextSrv) {
    this.tileServer = contextSrv.user.lightTheme ? 'CartoDB Positron' : 'CartoDB Positron';
    this.setMapSaturationClass();
  }

  setMapSaturationClass() {
    if (this.tileServer === 'CartoDB Dark') {
      this.saturationClass = 'map-darken';
    } else {
      this.saturationClass = '';
    }
  }
    onPanelTeardown() {
        if (this.map) this.map.remove();
    }
    onDataSnapshotLoad(snapshotData) {
        //this.onDataReceived(snapshotData);
    }
    //加载本地数据
  loadLocationDataFromFile(reload) {

    if (this.map && !reload) return;

    if (this.panel.snapshotLocationData) {
      this.locations = this.panel.snapshotLocationData;
      return;
    }

    if (this.panel.locationData === 'jsonp endpoint') {
      if (!this.panel.jsonpUrl || !this.panel.jsonpCallback) return;

      window.$.ajax({
        type: 'GET',
        url: this.panel.jsonpUrl ,
        contentType: 'application/json',
        //jsonpCallback: this.panel.jsonpCallback,
        dataType: 'json',
        success: (res) => {
          this.locations = res;
          this.render();
          //console.info('eee333')
        }
      });
    } else if (this.panel.locationData === 'json endpoint') {
      if (!this.panel.jsonUrl) return;

      window.$.getJSON(this.panel.jsonUrl).then((res) => {
          //console.info(res);
        this.locations = res;
        this.render();
      });
    } else if (this.panel.locationData === 'table') {
      // .. Do nothing
    } else if (this.panel.locationData !== 'geohash') {
      window.$.getJSON('public/plugins/grafana-worldmap-panel/data/' + this.panel.locationData + '.json')
        .then(this.reloadLocations.bind(this));
    }
  }

  reloadLocations(res) {
    this.locations = res;
    this.refresh();
  }

  onDataReceived(dataList) {
      //console.info(dataList);
    if (!dataList||dataList.length<=0) return;

    if (this.dashboard.snapshot && this.locations) {
      this.panel.snapshotLocationData = this.locations;
    }

    const data = [];

    //绑定本地数据
    if (this.panel.locationData === 'geohash') {
      this.dataFormatter.setGeohashValues(dataList, data);
    } else if (this.panel.locationData === 'table') {
      const tableData = dataList.map(DataFormatter.tableHandler.bind(this));
      this.dataFormatter.setTableValues(tableData, data);
    } else {
      this.series = dataList.map(this.seriesHandler.bind(this));
      console.info(this.series);
      this.dataFormatter.setValues(data);
    }
    this.data = data;
    this.bindAutoComplete();
     // console.info('onDataReceived');
    //console.info(this.data);
    this.updateThresholdData();

    this.render();
  }
    seriesHandler(seriesData) {
        const series = new TimeSeries({
            datapoints: seriesData.datapoints,
            alias: seriesData.target,

        });
        console.info(series)
        series.flotpairs = series.getFlotPairs(this.panel.nullPointMode);

        return series;
    }
	//智能提示
	bindAutoComplete(){
		 var this_ = this;
		 var dataArrFirst = this_.data;
		 var dataArrSecond = new Array();
     /*for(var i = 0;i < dataArrFirst.length;i++){
    	 dataArrSecond[i] = dataArrFirst[i].locationName;

     }*/
		 $( "#textVal" ).focus(function(){
         //智能提示
         $( "#textVal" ).autocomplete({
             matchContains: true,
             source: function (request, response) {
                               /*var res = $.ui.autocomplete.filter(
                                           dataArrSecond, request.term);*/
                 dataArrFirst.forEach(function (item) {
                     console.info(item.locationName.toString());
                     console.info(request.term.toString())
                     if(item.locationName.toString().indexOf(request.term.toString())>=0)
                     {
                         dataArrSecond.push(item.locationName);
                     }
                 });
                               response(dataArrSecond.slice(0,10));
                               },

    				minLength: 1

         });

     });

    $("#textVal").autocomplete({
		    focus: function (event, ui) {
		        var index = -1;
		        for (var i = 0; i < dataArrFirst.length; i++) {
		            //let reg=new RegExp(ui.item.label);
		            if ( dataArrFirst[i].locationName==ui.item.label) {
		                this_.panel.mapCenterLatitude = dataArrFirst[i].locationLatitude;
				            this_.panel.mapCenterLongitude = dataArrFirst[i].locationLongitude;
				            this_.mapCenterMoved = true;
				            if (this_.map)
                            {
                                this_.map.setZoom(18);
                                //this_.map.addFocus(this_.panel.mapCenterLatitude,
                                  //  this_.panel.mapCenterLongitude);
                            }


				            this_.render();
		                break;
		            }
		        }
		    }
		});

	}


  setNewMapCenter() {
    if (this.panel.mapCenter !== 'custom') {
      this.panel.mapCenterLatitude = mapCenters[this.panel.mapCenter].mapCenterLatitude;
      this.panel.mapCenterLongitude = mapCenters[this.panel.mapCenter].mapCenterLongitude;
    }
    this.mapCenterMoved = true;
    this.render();
  }

  play()
  {
      if(!this.series||this.series[0].datapoints.length<=0)return;
      //console.info('ppppp');
      if(this.panel.playStatus=='pause')
      {
          this.panel.playStatus='play';
      }else if(this.panel.playStatus=='stop')
      {
          this.panel.playStatus='play';
          this.playBack();
      }
  }
  pause()
  {
      this.panel.playStatus='pause';
  }
  stop()
  {
      this.panel.playStatus='stop';
      this.scope.playBackIndex=0;
  }

    timeStamp2String (time){
        var datetime = new Date();
        datetime.setTime(time);

        return datetime.Format("yyyy-MM-dd hh:mm:ss");
    };
  playBack()
  {
      const data1 = [];
      //console.info(this.series[0].datapoints.length);
      var  autoRefresh= this.$timeout(function(){
          if(this.scope.playBackIndex>=this.series[0].datapoints.length||this.panel.playStatus=='stop')
          {
              this.panel.playStatus='stop';
              this.scope.playBackIndex=0;
              this.$timeout.cancel(autoRefresh);
              this.updateThresholdData()
              return;
          }
          if(this.panel.playStatus=='play')
          {
              let timestap=this.dataFormatter.setPlayBackValues(data1,this.scope.playBackIndex++);
              //console.info(timestap);
              if(moment(timestap).isValid())
              {
                  this.timestep=moment(timestap).format(format);
              }
              this.data = data1;
              this.render();
              //this.scope.playBackIndex+=1;
              //console.info(this.scope.playBackIndex);
          }

         this.playBack();
      }.bind(this),this.scope.frequency);
  }

  setLayer() {
    if (this.panel.Layers !== 'light') {
      this.render();
    }
  }

  setZoom() {
    this.map.setZoom(this.panel.initialZoom || 1);
  }

  toggleLegend() {
    if (!this.panel.showLegend) {
      this.map.removeLegend();
    }
    this.render();
  }

  toggleStickyLabels() {
    this.map.clearCircles();
    this.render();
  }

  changeThresholds() {
    this.updateThresholdData();
    this.map.legend.update();
    this.render();
  }

  updateThresholdData() {
    this.data.thresholds = this.panel.thresholds.split(',').map((strValue) => {
      return Number(strValue.trim());
    });
    while (_.size(this.panel.colors) > _.size(this.data.thresholds) + 1) {
      // too many colors. remove the last one.
      this.panel.colors.pop();
    }
    while (_.size(this.panel.colors) < _.size(this.data.thresholds) + 1) {
      // not enough colors. add one.
      const newColor = 'rgba(50, 172, 45, 0.97)';
      this.panel.colors.push(newColor);
    }
  }

  changeLocationData() {
    this.loadLocationDataFromFile(true);

    if (this.panel.locationData === 'geohash') {
      this.render();
    }
  }
/* eslint class-methods-use-this: 0 */
  link(scope, elem, attrs, ctrl) {
        ctrl.play1=function ()
         {
                elem.find('#img1').attr('src',elem.find('#img1').attr('src')==  'public/plugins/grafana-worldmap-panel/images/ml-close-demo.png'?
                    'public/plugins/grafana-worldmap-panel/images/ml-open-demo.png':
                    'public/plugins/grafana-worldmap-panel/images/ml-close-demo.png');
                elem.find("#seachDivId").stop().animate({
                    width:'toggle'

                }, 230, function () {

                });

        }
        ctrl.play2=function () {
            elem.find('#img').attr('src',elem.find('#img').attr('src')==  'public/plugins/grafana-worldmap-panel/images/ml-close-demo.png'?
                'public/plugins/grafana-worldmap-panel/images/ml-open-demo.png':
                'public/plugins/grafana-worldmap-panel/images/ml-close-demo.png');
            elem.find("#con").stop().animate({
                width:'toggle'

            }, 230, function () {

            })
        }

    mapRenderer(scope, elem, attrs, ctrl);
  }
}

WorldmapCtrl.templateUrl = 'module.html';
