import 'app/plugins/panel/graph/graph'
import 'app/plugins/panel/graph/legend'
import DataProcessor from 'app/plugins/panel/graph/data_processor'
import {  coreModule } from 'app/core/core';

export function ChartDirect() {

    return {
        restrict: 'E',
        templateUrl: "public/plugins/grafana-worldmap-panel/chart.html",
        /*controller: ChartCtrl,
        bindToController: true,
        controllerAs: 'ctrl',*/
        //scope: {dismiss: "&"}
      link:function (scope, elem) {
        var ctrl=scope.ctrl;
        var processor = new DataProcessor(ctrl.panel);
        ctrl.hiddenSeries=[];

        //ctrl.xaxis=ctrl.panel.xaxis;

        function onDataReceived(dataList) {
          ctrl.dataList = dataList;
          //
          ctrl.seriesList = processor.getSeriesList({
            dataList: dataList,
            range: ctrl.range,
          });

        }
        console.info(scope.selectedPoints);
        onDataReceived(scope.selectedPoints)
        ctrl.render(ctrl.seriesList)
        ctrl.events.emit('legend-rendering-complete');
      }
    };
}

coreModule.directive('cs', ChartDirect);
