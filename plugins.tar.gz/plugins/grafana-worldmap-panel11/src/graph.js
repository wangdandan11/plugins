import { EventManager } from 'app/features/annotations/all';
import 'vendor/flot/jquery.flot';
