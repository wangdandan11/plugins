import './css/leaflet.css!';
import WorldMap from './worldmap';

export default function link(scope, elem, attrs, ctrl)
{
      const mapContainer = elem.find('.mapcontainer');


      ctrl.events.on('render', () =>
      {
        render();
        ctrl.renderingCompleted();
      });
      ctrl.setMapMode=function()
      {
          if (ctrl.map)
          {

              ctrl.map.removeCircles();
              ctrl.map.removeHeatMap();
          }
          render();

      }
      ctrl.restart=function () {
          //console.info('rrrr');
          if (ctrl.map)
          {
              //console.info('yyyy');
              ctrl.map.remove();
          }
          render();

      }

      function render()
      {
          //console.info(ctrl.data)
          if (!ctrl.data) return;
            //console.info('render');
              var time=ctrl.panel.mapMode==1?350:0;
              var deferred = ctrl.q.defer();
              var promise = deferred.promise;
              promise.then(function () {
                  if(!ctrl.map)return;
                  //console.info(ctrl.panel.mapMode)
                  if(ctrl.panel.mapMode==1)
                  {
                      ctrl.map.drawCircles();
                  }else
                  {
                      ctrl.map.createHeatLayer();
                  }


                  if (ctrl.mapCenterMoved) ctrl.map.panToMapCenter();

                  if (!ctrl.map.legend && ctrl.panel.showLegend) ctrl.map.createLegend();
                //ctrl.map.invalidateSize();
              })
                if(!ctrl.map)
                    ctrl.map = new WorldMap(ctrl, mapContainer[0]);
              //else ctrl.map.invalidateSize();

              ctrl.$timeout(function () {
                  deferred.resolve('ok');
                  ///console.info('aaatttt')
              },time);



          //ctrl.map.drawCircles();
          //ctrl.map.createHeatLayer();

      }
}
