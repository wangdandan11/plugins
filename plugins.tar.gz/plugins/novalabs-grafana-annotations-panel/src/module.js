import {AnnotationsCtrl} from './annotations_ctrl';

export {
  AnnotationsCtrl as PanelCtrl
};
